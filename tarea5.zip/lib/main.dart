import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.topCenter,
      child: Container(
        margin: const EdgeInsets.only(top: 20),
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: Color.fromARGB(82, 255, 0, 153),
              width: 10,
            )),
        width: 280,
        height: 280,
        alignment: Alignment.center,
        child: const Text(
          'S',
          textDirection: TextDirection.ltr,
          style: TextStyle(
            fontSize: 180,
            color: Color.fromARGB(82, 255, 0, 153),
          ),
        ),
      ),
    );
  }
}
