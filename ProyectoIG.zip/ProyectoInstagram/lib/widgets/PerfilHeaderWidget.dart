import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ejercicio_instagram/data/data.dart';

//Header de la aplicacion
Widget PerfilHeader(BuildContext context) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(color: Colors.black),
    child: Padding(
      padding: const EdgeInsets.only(left: 18.0, right: 18.0, bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: Color(0xff74EDED),
                //Imagen de perfil
                backgroundImage: AssetImage('assets/images/chico.jpg'),
              ),

              //Seguidores, seguidos y posts
              Row(
                children: [
                  Column(
                    children: [
                      Text(
                        "23",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Colors.white),
                      ),
                      Text(
                        "Posts",
                        style: TextStyle(
                            fontSize: 15,
                            letterSpacing: 0.4,
                            color: Colors.white),
                      )
                    ],
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  Column(
                    children: [
                      Text(
                        "1.5M",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Colors.white),
                      ),
                      Text(
                        "Followers",
                        style: TextStyle(
                            letterSpacing: 0.4,
                            fontSize: 15,
                            color: Colors.white),
                      )
                    ],
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  Column(
                    children: [
                      Text(
                        "234",
                        style: TextStyle(
                            letterSpacing: 0.4,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Colors.white),
                      ),
                      Text(
                        "Following",
                        style: TextStyle(
                            letterSpacing: 0.4,
                            fontSize: 15,
                            color: Colors.white),
                      )
                    ],
                  ),
                  SizedBox(
                    width: 15,
                  ),
                ],
              )
            ],
          ),
          SizedBox(
            height: 8,
          ),
          Text(
            //Nombre de perfil
            "Juan Palomo",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 16,
              letterSpacing: 0.4,
            ),
          ),
          SizedBox(
            height: 4,
          ),
          Text(
            //Biografia
            "Programador junior",
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 0.4,
            ),
          ),
          SizedBox(
            height: 20,
          ),
          actions(context),
          SizedBox(
            height: 20,
          ),
          //Contenedor en el que se especifica la posicion y tamaño de la imagen y texto
          //asi como la direccion del scroll y el numero de imagenes de las stories que estan definidas en la clase data
          Container(
            height: 85,
            child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: elementos.length,
              itemBuilder: (context, index) {
                return Row(
                  children: [
                    Column(
                      children: [
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: Colors.grey,
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: CircleAvatar(
                              backgroundImage:
                                  AssetImage(elementos[index].thumbnail),
                              radius: 28,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            elementos[index].title,
                            style: TextStyle(fontSize: 13, color: Colors.white),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      width: 10,
                    )
                  ],
                );
              },
            ),
          )
        ],
      ),
    ),
  );
}

Widget actions(BuildContext context) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
      Column(
        children: [
          OutlinedButton(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text("Following",
                  style: TextStyle(color: Colors.white, fontSize: 10)),
            ),
            style: OutlinedButton.styleFrom(
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                minimumSize: Size(0, 30),
                side: BorderSide(
                  color: Colors.grey,
                )),
            onPressed: () {},
          ),
        ],
      ),
      Column(
        children: [
          OutlinedButton(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text("Message",
                  style: TextStyle(color: Colors.white, fontSize: 10)),
            ),
            style: OutlinedButton.styleFrom(
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                minimumSize: Size(0, 30),
                side: BorderSide(
                  color: Colors.grey,
                )),
            onPressed: () {},
          ),
        ],
      ),
      Column(
        children: [
          OutlinedButton(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text("Email",
                  style: TextStyle(color: Colors.white, fontSize: 10)),
            ),
            style: OutlinedButton.styleFrom(
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                minimumSize: Size(0, 30),
                side: BorderSide(
                  color: Colors.grey,
                )),
            onPressed: () {},
          ),
        ],
      ),
      Column(
        children: [
          OutlinedButton(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Icon(Icons.expand_more, color: Colors.white),
            ),
            style: OutlinedButton.styleFrom(
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                minimumSize: Size(0, 30),
                side: BorderSide(
                  color: Colors.grey,
                )),
            onPressed: () {},
          ),
        ],
      ),
    ],
  );
}
