import 'package:flutter/material.dart';

class Galeria extends StatefulWidget {
  @override
  _GaleriaState createState() => _GaleriaState();
}

//Lista de fotos que se generan solas en la pagina placeimg a partir de una palabra
class _GaleriaState extends State<Galeria> {
  late OverlayEntry _popupDialog;
  List<String> images = [
    'https://placeimg.com/640/480/perro',
    'https://placeimg.com/640/480/naturaleza',
    'https://placeimg.com/640/480/gente',
    'https://placeimg.com/640/480/tecnologia',
    'https://placeimg.com/640/480/rol',
    'https://placeimg.com/640/480/amigos',
    'https://placeimg.com/640/480/malaga',
    'https://placeimg.com/640/480/viajes',
    'https://placeimg.com/640/480/avion',
    'https://placeimg.com/640/480/videojuegos',
    'https://placeimg.com/640/480/personas',
    'https://placeimg.com/640/480/informatica',
    'https://placeimg.com/640/480/programacion',
    'https://placeimg.com/640/480/flutter',
    'https://placeimg.com/640/480/codigo',
    'https://placeimg.com/640/480/gente',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.count(
        crossAxisCount: 3,
        childAspectRatio: 1.0,
        children: images.map(_createGridTileWidget).toList(),
      ),
    );
  }

  Widget _createGridTileWidget(String url) => Builder(
        builder: (context) => GestureDetector(
          onLongPress: () {
            _popupDialog = _createPopupDialog(url);
            Overlay.of(context)!.insert(_popupDialog);
          },
          onLongPressEnd: (details) => _popupDialog.remove(),
          child: Image.network(url, fit: BoxFit.cover),
        ),
      );

  OverlayEntry _createPopupDialog(String url) {
    return OverlayEntry(
      builder: (context) => AnimatedDialog(
        child: _PopUp(url),
      ),
    );
  }

//Widget en el que se inserta una foto principal y un nombre de perfil
  Widget _fotoTitulo() => Container(
      width: double.infinity,
      color: Colors.black,
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage:
              NetworkImage('https://placeimg.com/640/480/personas'),
        ),
        title: Text(
          'Juan Palomo',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
        ),
      ));

  Widget _BarraAct() => Container(
        padding: EdgeInsets.symmetric(vertical: 10.0),
        color: Colors.black,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Icon(
              Icons.favorite_border,
              color: Colors.white,
            ),
            Icon(
              Icons.chat_bubble_outline_outlined,
              color: Colors.white,
            ),
            Icon(
              Icons.send,
              color: Colors.white,
            ),
          ],
        ),
      );

  Widget _PopUp(String url) => Container(
        padding: EdgeInsets.symmetric(horizontal: 16.0),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _fotoTitulo(),
              Image.network(url, fit: BoxFit.fitWidth),
              _BarraAct(),
            ],
          ),
        ),
      );
}

class AnimatedDialog extends StatefulWidget {
  const AnimatedDialog({Key? key, required this.child}) : super(key: key);

  final Widget child;

  @override
  State<StatefulWidget> createState() => AnimatedDialogState();
}

class AnimatedDialogState extends State<AnimatedDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> opacityAnimation;
  late Animation<double> scaleAnimation;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    scaleAnimation =
        CurvedAnimation(parent: controller, curve: Curves.easeOutExpo);
    opacityAnimation = Tween<double>(begin: 0.0, end: 0.6).animate(
        CurvedAnimation(parent: controller, curve: Curves.easeOutExpo));

    controller.addListener(() => setState(() {}));
    controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withOpacity(opacityAnimation.value),
      child: Center(
        child: FadeTransition(
          opacity: scaleAnimation,
          child: ScaleTransition(
            scale: scaleAnimation,
            child: widget.child,
          ),
        ),
      ),
    );
  }
}
