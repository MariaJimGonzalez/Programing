import 'package:flutter/material.dart';

//Clase Reels que retorna un container, sera llamada en Perfil
class Reels extends StatefulWidget {
  @override
  _ReelState createState() => _ReelState();
}

class _ReelState extends State<Reels> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
