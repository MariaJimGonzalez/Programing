import 'package:flutter/material.dart';

//Clase Igtv que retorna un container, sera llamada en Perfil

class Igtv extends StatefulWidget {
  @override
  _igtvState createState() => _igtvState();
}

class _igtvState extends State<Igtv> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
