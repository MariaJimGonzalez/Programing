import 'package:flutter/material.dart';
import 'package:ejercicio_instagram/screens/Galeria.dart';
import 'package:ejercicio_instagram/screens/Igtv.dart';
import 'package:ejercicio_instagram/screens/Reels.dart';
import 'package:ejercicio_instagram/widgets/PerfilHeaderWidget.dart';

//Clase Perfil, es la clase principal que se compone de las demas

class Perfil extends StatefulWidget {
  @override
  _PerfilState createState() => _PerfilState();
}

class _PerfilState extends State<Perfil> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //Appbar que contiene los iconos y el nombre
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(40),
        child: Container(
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: Colors.grey),
            ),
          ),
          child: AppBar(
            elevation: 0,
            backgroundColor: Colors.black,
            centerTitle: false,
            leading: IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                ),
                onPressed: () {}),
            title: Text(
              "Juan Palomo",
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            ),
            actions: [
              IconButton(
                  icon: Icon(
                    Icons.more_horiz,
                    color: Colors.white,
                  ),
                  onPressed: () {}),
            ],
          ),
        ),
      ),

      //Cuerpo de la aplicacion con los iconos de los reels, igtv y el grill
      body: DefaultTabController(
        length: 3,
        child: NestedScrollView(
          headerSliverBuilder: (context, _) {
            return [
              SliverList(
                  delegate: SliverChildListDelegate([
                //Llamada al header
                PerfilHeader(context),
              ]))
            ];
          },
          body: Column(children: [
            Material(
              color: Colors.black,
              child: TabBar(
                labelColor: Colors.black,
                unselectedLabelColor: Colors.black,
                indicatorWeight: 1,
                indicatorColor: Colors.black,
                tabs: [
                  Tab(
                    icon: Icon(
                      Icons.grid_on_sharp,
                      color: Colors.white,
                    ),
                  ),
                  Tab(
                    icon: Image.asset('assets/images/reels.png',
                        height: 30, width: 30, color: Colors.white),
                  ),
                  Tab(
                    icon: Image.asset('assets/images/igtv.png',
                        height: 30, width: 30, color: Colors.white),
                  ),
                ],
              ),
            ),
            Expanded(
                child: TabBarView(children: [
              //Llamada a las otras clases
              Galeria(),
              Reels(),
              Igtv(),
            ]))
          ]),
        ),
      ),

      //Barra inferior con sus iconos
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            backgroundColor: Colors.black,
            icon: Icon(
              Icons.home_filled,
              color: Colors.white,
            ),
            label: 'home',
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.black,
            icon: Icon(Icons.search, color: Colors.white),
            label: 'search',
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.black,
            icon: Icon(Icons.add_box_outlined, color: Colors.white),
            label: 'add',
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.black,
            icon: Icon(Icons.favorite_border_outlined, color: Colors.white),
            label: 'favorite',
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.black,
            icon: Icon(Icons.person, color: Colors.white),
            label: 'Person',
          ),
        ],
      ),
    );
  }
}
