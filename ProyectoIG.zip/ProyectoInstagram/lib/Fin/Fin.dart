import 'package:ejercicio_instagram/MenuLateral/Menu.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

//Esta clase inserta un gif ocupando toda la pantalla

class Fin extends StatefulWidget {
  @override
  _FinState createState() => _FinState();
}

class _FinState extends State<Fin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Menu(),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/noche.gif"), fit: BoxFit.cover),
        ),
      ),
    );
  }
}
