class Highlight {
  String thumbnail;
  String title;
  Highlight({required this.thumbnail, required this.title});
}

//Imagenes para las stories guardadas
List<Highlight> elementos = [
  Highlight(thumbnail: 'assets/images/anime.jpg', title: "Animes"),
  Highlight(thumbnail: 'assets/images/larp.jpg', title: "LARP"),
  Highlight(thumbnail: 'assets/images/nature.jpg', title: "Naturaleza 🏞"),
  Highlight(thumbnail: 'assets/images/perro.jpg', title: "Sauron ❤️"),
  Highlight(thumbnail: 'assets/images/juegos.png', title: "Juegos"),
  Highlight(thumbnail: 'assets/images/amigos.jpg', title: "Amigos"),
];
