import 'package:ejercicio_instagram/Fin/Fin.dart';
import 'package:ejercicio_instagram/Inicio/Inicio.dart';
import 'package:ejercicio_instagram/screens/Perfil.dart';
import 'package:flutter/material.dart';

class Menu extends StatelessWidget {
  const Menu({super.key});

  //BuildContext get context => ;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[Columnas(context)],
      ),
    );
  }

  Column Columnas(BuildContext context) {
    return Column(
      children: [
        ListTile(
          title: Text(
            "Inicio",
            style: EstiloBotonesTexto(),
          ),
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Inicio()));
          },
        ),
        ListTile(
          title: Text(
            "Instagram",
            style: EstiloBotonesTexto(),
          ),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Perfil()));
          },
        ),
        ListTile(
          title: Text(
            "Fin",
            style: EstiloBotonesTexto(),
          ),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Fin()));
          },
        ),
      ],
    );
  }

//Metodo para dar formato al texto de la cabecera
  TextStyle EstiloCabeceraTexto() {
    return const TextStyle(
      color: Color.fromARGB(255, 76, 5, 107),
      fontSize: 30,
      fontFamily: 'mermaid',
    );
  }

//Metodo para dar formato al texto del menu
  TextStyle EstiloBotonesTexto() => const TextStyle(
        color: Color.fromARGB(255, 76, 5, 107),
        fontSize: 30,
        fontFamily: 'mermaid',
      );

//Metodo para dar formato a los botones del menu, color
  Color EstiloBotonesColor() => const Color.fromARGB(255, 213, 225, 231);
}
