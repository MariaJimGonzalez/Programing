import 'package:ejercicio_instagram/Fin/Fin.dart';
import 'package:ejercicio_instagram/Inicio/Inicio.dart';
import 'package:ejercicio_instagram/screens/Perfil.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter instagram',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Fin(),
    );
  }
}
