import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: "Contador de clics",
        home: const MiClase(
          title: 'Contador de clics',
        ));
  }
}

class MiClase extends StatefulWidget {
  const MiClase({super.key, required this.title});
  final String title;

  @override
  State<MiClase> createState() => _MiClase();
}

class _MiClase extends State<MiClase> {
  int _contador = 0;

  void _incrementar() {
    setState(() {
      _contador++;
    });
  }

  void _decrementar() {
    setState(() {
      _contador--;
    });
  }

  void _contadorCero() {
    setState(() {
      _contador = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(170, 135, 255, 22),
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Has pulsado...',
              style: TextStyle(
                fontSize: 60,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 108, 207, 10),
              ),
            ),
            Text('$_contador',
                style: TextStyle(
                  fontSize: 60,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 108, 207, 10),
                )),
          ],
        ),
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          FloatingActionButton(
            onPressed: _incrementar,
            tooltip: 'Increment',
            child: Icon(Icons.add),
            backgroundColor: Color.fromARGB(255, 108, 207, 10),
          ),
          SizedBox(width: 50),
          FloatingActionButton(
            onPressed: _decrementar,
            tooltip: 'Decrement',
            child: Icon(Icons.remove),
            backgroundColor: Color.fromARGB(255, 108, 207, 10),
          ),
          SizedBox(width: 50),
          FloatingActionButton(
            onPressed: _contadorCero,
            tooltip: 'contadorCero',
            child: Icon(Icons.android),
            backgroundColor: Color.fromARGB(255, 108, 207, 10),
          ),
        ],
      ),
    );
  }
}
