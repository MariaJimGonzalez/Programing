import 'dart:io';

import 'package:flutter/material.dart';

class menu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          const UserAccountsDrawerHeader(
            accountName: Text("Pedrito"),
            accountEmail: Text("Pedrito@gmail.com"),
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: NetworkImage(
                        "https://www.psdgraphics.com/wp-content/uploads/2019/06/seamless-geometric-shapes.png"),
                    fit: BoxFit.cover)),
          ),
          Ink(
            color: Color.fromARGB(255, 196, 0, 118),
            child: ListTile(
              title: const Text(
                "Home",
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {},
            ),
          ),
          Ink(
            color: Color.fromARGB(255, 196, 0, 118),
            child: ListTile(
              title: const Text(
                "About Us",
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {},
            ),
          ),
          Ink(
            color: Color.fromARGB(255, 196, 0, 118),
            child: ListTile(
              title: const Text(
                "Work",
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {},
            ),
          ),
          Ink(
            color: Color.fromARGB(255, 196, 0, 118),
            child: ListTile(
              title: const Text(
                "Experience",
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {},
            ),
          ),
          Ink(
            color: Color.fromARGB(255, 196, 0, 118),
            child: ListTile(
              title: const Text(
                "Exit",
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                exit(0);
              },
            ),
          ),
        ],
      ),
    );
  }
}
