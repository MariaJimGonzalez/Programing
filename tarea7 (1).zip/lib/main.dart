import 'package:ejercicioflutter8/menu.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Prueba Drawer a la derecha',
      home: Scaffold(
        appBar: AppBar(
          title: const Center(
            child: Text('Barra superior'),
          ),
        ),
        endDrawer: menu(),
        body: const Center(
          child: Text('Cuerpo central'),
        ),
        persistentFooterButtons: <Widget>[
          ElevatedButton(
            onPressed: () {},
            child: const Icon(
              Icons.add,
              color: Colors.white,
            ),
          ),
          ElevatedButton(
            onPressed: () {},
            child: const Icon(
              Icons.clear,
              color: Colors.white,
            ),
          ),
        ],
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: () {},
        ),
      ),
    );
  }
}
