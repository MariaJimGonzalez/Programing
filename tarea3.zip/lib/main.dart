import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter tarea 3: Iconos',
        home: Scaffold(
          appBar: AppBar(
            title: Center(
              child: Text('Tarea 3'),
            ),
          ),
          body: Container(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('assets/images/drak.png',
                          height: 300, width: 100),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('LARP EVENTS: DRACHENFEST',
                          style: TextStyle(fontSize: 40))
                    ],
                  ),
                ]),
            alignment: Alignment.center,
          ),
        ));
  }
}
